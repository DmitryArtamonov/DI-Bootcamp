// const fsPromises = require('fs').promises;

// async function f() {
//     console.log("hello");
//     const data = await fsPromises.readFile('data.json')
//     .catch((err) => console.error('Failed to read file', err));
//     console.log(JSON.parse(data.toString()));
// }

// f()