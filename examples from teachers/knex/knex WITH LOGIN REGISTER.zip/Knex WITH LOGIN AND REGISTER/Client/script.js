const submit = document.getElementById("submit");
const username = document.getElementById("username");
const password = document.getElementById("password");
const message = document.getElementById("message");
async function register() {
  const data = JSON.stringify({
    username: username.value,
    password: password.value,
  });
  const res = await fetch("http://localhost:3000/users", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: data,
  });
  console.log(data);
  const newData = await res.json();
  message.innerHTML = newData;
  console.log(res.status);
}

submit.addEventListener("click", (e) => {
  e.preventDefault();
  register();
});

const submit1 = document.getElementById("submit1");
const username1 = document.getElementById("username1");
const password1 = document.getElementById("password1");
const message1 = document.getElementById("message1");
async function login() {
  const data = JSON.stringify({
    username: username1.value,
    password: password1.value,
  });
  const res = await fetch("http://localhost:3000/login", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: data,
  });
  console.log(data);
  const newData = await res.json();
  message1.innerHTML = newData;
  console.log(res.status);
}

submit1.addEventListener("click", (e) => {
  e.preventDefault();
  login();
});

const checkInputs = () => {
  const isUsernameEmpty = username.value.trim() === "";
  const isPasswordEmpty = password.value.trim() === "";
  submit.disabled = isUsernameEmpty || isPasswordEmpty;

  const isUsernameEmpty1 = username1.value.trim() === "";
  const isPasswordEmpty1 = password1.value.trim() === "";
  submit1.disabled = isUsernameEmpty1 || isPasswordEmpty1;
};
checkInputs();
username.addEventListener("input", checkInputs);
password.addEventListener("input", checkInputs);

username1.addEventListener("input", checkInputs);
password1.addEventListener("input", checkInputs);
