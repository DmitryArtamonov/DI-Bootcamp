const { getAllUsers, createUser, getUserByUsername } = require("../models/users");
const getUsers = async (req, res) => {
  try {
    const users = await getAllUsers();
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const createNewUser = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = { username, password };
    const checkUsername = await getUserByUsername(username);
    if (!checkUsername) {
      const result = await createUser(user);
      res.json("User created successfully");
    } else {
      res.json("username already exists");
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

const login = async (req, res) => {
  console.log("got login request");
  try {
    const { username, password } = req.body;
    const user = await getUserByUsername(username);
    console.log(user);
    if (!user) {
      return res.status(401).json("Invalid email or password");
    } else if (password != user.password) {
      return res.status(401).json("Invalid  password");
    }
    console.log(user);
    res.status(200).json("Successfully Logged in");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = {
  getUsers,
  createNewUser,
  login,
};
