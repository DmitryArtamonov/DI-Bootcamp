//Model for each table
const db = require("../config/Database");

const getAllUsers = async () => {
  const answer = await db.select("*").from("users");
  return answer;
};

const createUser = async (user) => {
  const answer = db("users").insert(user);
  return answer;
};

const getUserByUsername = async (username) => {
  return db("users").where("username", username).first();
};

module.exports = {
  getAllUsers,
  createUser,
  getUserByUsername,
};
