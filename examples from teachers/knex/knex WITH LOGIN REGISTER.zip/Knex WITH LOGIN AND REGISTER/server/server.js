const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();
const app = express();
const routes = require("./routes/routes");
app.use(cors());
app.use(express.json());
app.use(routes);
// app.get("/", async (req, res) => {
//   const answer = await db.select("*").from("users");
//   console.log(answer);
//   console.log(req.body);
//   res.json("hello");
// });

// app.post("/", async (req, res) => {
//   //   const answer = await db.select("*").from("users");
//   //   console.log(answer);
//   console.log(req.body);

//   res.status(200).json("ok");
// });

app.listen(3000, () => console.log("listening"));
